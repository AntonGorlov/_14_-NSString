//
//  ViewController.h
//  StringTest (Lesson 14)
//
//  Created by Anton Gorlov on 10.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

