//
//  AppDelegate.m
//  StringTest (Lesson 14)
//
//  Created by Anton Gorlov on 10.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
/*
    //Сравниваем строки
    NSString*String1 = @"String 1";
    NSString*String2 = @"String 2";
    NSArray*array = [NSArray arrayWithObjects:String1,String2, nil];
    
    for (NSString* string in array){
        if ([string isEqualToString:@"String 2"]) {
            NSLog(@"index=%lu",[array indexOfObject:string]);
        }
    }
    
    NSString *s4 = @"Bill";
    NSString *s5 = @"John";
    BOOL equal = [s4 isEqualToString:s5];
    NSLog(@"Strings is equal? %@", equal? @"YES" : @"NO");
    
 */
/*
    NSString* string=@"Hello World";
    NSLog(@"%@",string);
    
    //Найдем range в слове "World".
    
    NSRange range=[string rangeOfString:@"World"];
    NSLog(@" range %@",NSStringFromRange(range));
*/

    /*
    NSString* string=@"Hello World";
    
    
    //если в  range нет слова "world" с маленькой буквы.
    
    NSRange range=[string rangeOfString:@"world"];
   
    if (range.location !=NSNotFound) {
         NSLog(@" range %@",NSStringFromRange(range));
    }else{
        NSLog(@"not found");
    }
*/
    
/*
  //  поиск  range с доп параметрами.options:  NSCaseInsensitiveSearch -ищет с маленькой буквы
    
  NSString* string=@"Hello World";
    NSRange range=[string rangeOfString:@"world" options:  NSCaseInsensitiveSearch];
    if (range.location !=NSNotFound) {
        NSLog(@" range %@",NSStringFromRange(range));
    }else{
        NSLog(@"not found");
    }
*/
    
// работас большим текстом
    NSString* text=@"Summer is over and it is autumn again, beautiful as ever. Even if you are no artist at all you can see its beauty. It is a season when the trees are simply fantastic — yellow, red, green and brown, not just one brown, but browns of all possible shades: light brown, dark brown, yellowish brown and all of a richness that only an artist can see and describe.Victor is back in Vorontsovo. He has just come but his thoughts are still in Kiev where the autumn is so beautiful. This is not his first visit there. He has already been to Kiev and he has learnt its streets, roads, parks, theatres, cinemas and old and new beautiful buildings. He easily recognizes the streets, buildings, buses, parks and the noise. Noise is everywhere. Now he is with his classmates and the usual talk begins";
/*
    //давайте вырежем до какого-то индекса.
    text=[text substringToIndex:30];
    NSLog(@"%@",text);
    
    //обрежем все до фразы "Victor is back"
    NSRange range=[text rangeOfString:@"Victor is back"]; //найдем range где он находиться
    if (range.location !=NSNotFound) { // проверим найдено ли,если да,то обрежем строку до этого индекса (слова)
        text=[text substringToIndex:range.location];
    }
*/
/*
  //посчитаем,какое количество слов "is" в тексте.
    NSRange searchRange=NSMakeRange(0, [text length]); // от 0 и по всей длине текста
    NSInteger counter=0;
    while (YES) {
        NSRange range=[text rangeOfString:@"is" options:0 range:searchRange];
        if (range.location !=NSNotFound) { //если нашли по индексу
            NSInteger index = range.location+range.length;//узнаем индекс  у слова
            searchRange.location=index;
            //как посчитать длину?
            searchRange.length=[text length]-index;
            NSLog(@"%@",NSStringFromRange(range));
            counter++;
        }else{
            break;
        }
    }// выводим кол-во найденых строк
    NSLog(@"counter- %lu",counter);
*/

/*
    //Все слова "Is" можно заменить на другое слово
    text=[text stringByReplacingOccurrencesOfString:@"is" withString:@"BAm_BarBia"];
      NSLog(@"%@",text);
    
    //все буквы в тексте большие
    text=[text uppercaseString];
      NSLog(@"%@",text);
    
    //каждое слово с большой буквы
    
    text=[text capitalizedString];
      NSLog(@"%@",text);
*/

/*
    //вывод любого числа (число не в тексте)
    NSLog(@"%d",[@"156" intValue]);
    
*/
    //Метод,который соз массив строк разделенный какой-то строкой
    
    NSArray* array=[text componentsSeparatedByString:@" "];
    NSLog(@"%@",array);
    
    //метод,который соединяет компоненты какой-то строкой
    text=[array componentsJoinedByString:@"__"];
    NSLog(@"%@",text);
    
    
    
    
    
    
    
    
    
    
    // Override point for customization after application launch.
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
