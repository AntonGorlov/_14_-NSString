//
//  ViewController.m
//  HomeWork Lesson 14 (NSString)
//
//  Created by Anton Gorlov on 12.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
